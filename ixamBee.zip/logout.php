<?php
	require 'db.php';
	$comman->logout();
	header('Location:login.php');
?>